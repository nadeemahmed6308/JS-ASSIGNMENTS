function AddPost(){ 
    return(
<div>
<h1>Post Your Add</h1>


     <div class="form" id="form">
       <div class="inner-form">
        <p>Add Title</p>
        <input type="text" name="" id="title" />
        <p>Add Description</p>
        <input type="text" name="" id="description" />
        <p>Set A Price</p>
        <input type="text" name="" id="price" />
        
    </div>
        <div class="img-div">
        <img src="" alt="" width="200px" id="image" />
        <div>
        <input type="file" name="upload" />
    </div>
     </div>
     <button id="post-btn">Post</button>
    </div>

</div>
    );
}

export default AddPost;