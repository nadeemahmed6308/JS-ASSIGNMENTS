import Footer from '../../Components/Footer'
import Header from '../../Components/Header';

function Login(){
    return ( 
         <div>
            <div class="alert alert-primary" role="alert">
            Login page
             </div>
             <Header />
            <Footer />
        </div>
    );
}

export default Login;