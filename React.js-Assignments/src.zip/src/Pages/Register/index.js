import Footer from '../../Components/Footer'
import Header from '../../Components/Header';

function Register(){
    return ( 
         <div>
            <div class="alert alert-primary" role="alert">
            signUp page
            </div>
            <Header />
            <Footer />
        </div>
    );
}

export default Register;