import { auth, onAuthStateChanged, getAds, logout, postAdToDb } from '../config/config.js';

onAuthStateChanged(auth, (user) => {
  if (user) {
    // Agar user logged in hai
    const uid = user.uid;
    const userEmail = document.getElementById('email');
    userEmail.innerText = user.email;
    getAds();
  } else {
    // Agar user logged out hai
    const links = document.getElementById('links-div');
    links.style.display = 'block';
    const dashboard = document.getElementById('dashboard');
    dashboard.style.display = 'none';
    logout();
    window.location.href = '../registration/login/login.html';
  }
});

// Cart items ka count nikalne wala function
function getCartCount() {
  const cartItems = JSON.parse(localStorage.getItem('cart'));
  if (cartItems) {
    const count = document.getElementById('count');
    count.innerHTML = cartItems.length;
  }
}
getCartCount();

// My Ads pe jaane wala function
window.myAds = function() {
  location.href = '../myAds/myAds.html';
}

// Logout function
window.signout = function() {
  logout();
}

// Home pe jaane wala function
window.gotohome = function() {
  window.location.href = "../../index.html";
  localStorage.setItem('cart', JSON.stringify(cartItems));
}


// Ad submit karne wala function
window.onSubmit = function() {
  const uid = auth.currentUser.uid;
  const title = document.getElementById('title').value
  
const description = document.getElementById('description').value
  
  const amount = document.getElementById('amount').value
  
  const image = document.getElementById('file').files[0]
  
  const createdAt = new Date();
  const ad = {
    title,
    description,
    amount,
    image,
    uid,
    createdAt
  };

  postAdToDb(ad);

  // Input fields ko clear karna
  //for (let i = 0; i < allInputs.length; i++) {
   // allInputs[i].value = ''; }
}

// go to Cart function 
window.gotoCart = function() {
  window.location.href = '../AdToCart/AdToCart.html'
}