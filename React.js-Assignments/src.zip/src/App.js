import Home from './Pages/Home'
import './App.css';
import Login from './Pages/Login';
import Register from './Pages/Register';

function App() {
  return (
    <div>
    <Home />
    <Login />
    <Register />
    </div>
  );
}

export default App;

