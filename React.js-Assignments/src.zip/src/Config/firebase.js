import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, doc, setDoc, addDoc } from "firebase/firestore";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase-auth";

const firebaseConfig = {
    apiKey: "AIzaSyCnMnsBWvKrWV6x5O-SzdBL9kEP_jdcWds",
    authDomain: "nadeem-48a3f.firebaseapp.com",
    projectId: "nadeem-48a3f",
    storageBucket: "nadeem-48a3f.appspot.com",
    messagingSenderId: "558705787773",
    appId: "1:558705787773:web:8ac24c5cc441f656818214"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export async function getAllProducts() {
    const querySnapshot = await getDocs(collection(db, "ads"));
    const products = []
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        console.log(doc.id, " => ", doc.data());
        products.push({ id: doc.id, ...doc.data() })
    })

    return products
}

// Post Add Function 
export async function postAdToDb(ad){
    try {
      const storageRef = ref(storage, `ads/${ad.image}`);
      await uploadBytes(storageRef, ad.image)
      const url = await getDownloadURL(storageRef)
      ad.image = url
      await addDoc(collection(db, "ads"), ad)
      alert('Data added successfully!')
  } catch (e) {
      alert(e.message)
  }
  }

  // get ads function 
 export async function getAds(){
    const querySnapshot = await getDocs(collection(db, "ads"));
    const array = []
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    console.log(doc.id, " => ", doc.data());
    const ad = doc.data()
    const id = doc.id
    ads.push(ad)
  });
  return ads
  }



  export async function register(user){
    const{ fullname, email, password, phoneNumber } = user 
  const {user: {uid}} = await createUserWithEmailAndPassword(auth, email, password)
 const userRef = doc(db, "users", uid);
 await setDoc(userRef, {fullname,
    email,
    password,
    phoneNumber}); 
  alert('Registered Successfully!')
  }

   
   
   // login function 
   export async function login(user) {
     const { email, password } = user
    await signInWithEmailAndPassword(auth, email, password);
         alert('logged in sucessfully')
   }