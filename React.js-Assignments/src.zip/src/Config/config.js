


import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-storage.js"; 


// Initialize Firebase



const storage = getStorage(app);



 
 
// Post Add Function 
 async function postAdToDb(ad){
  try {
    const storageRef = ref(storage, `ads/${ad.image}`);
    await uploadBytes(storageRef, ad.image)
    const url = await getDownloadURL(storageRef)
    ad.image = url
    await addDoc(collection(db, "ads"), ad)
    alert('Data added successfully!')
} catch (e) {
    alert(e.message)
}
}


// get ads function 
async function getAds(){
  const querySnapshot = await getDocs(collection(db, "ads"));
  const array = []
querySnapshot.forEach((doc) => {
  // doc.data() is never undefined for query doc snapshots
  console.log(doc.id, " => ", doc.data());
  const ad = doc.data()
  const id = doc.id
  ads.push(ad)
});
return ads
}
 

 
export {
  register,
  login,
  auth,
  onAuthStateChanged,
  postAdToDb,
  getAds
}

// jis bhi function mein asynchronus chal raha hoga tou or bahar usse return karna hoga tou bhar bhi synchronus ko 
// asynchronus karna hoga