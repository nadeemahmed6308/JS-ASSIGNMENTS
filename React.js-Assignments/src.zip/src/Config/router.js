import {
    createBrowserRouter,
    RouterProvider,
} from "react-router-dom"
import Home from '../Pages/Home'
import Login from '../Pages/Login'
import PostAd from '../Pages/PostAd'
import Register from '../Pages/Register'
import Detail from '../Pages/Detail'

const router = createBrowserRouter([
    {
        path: "/",
        element: <Home />,
    },
    {
        path: "/Login",
        element: <Login />,
    },
    {
        path: "/Register",
        element: <Register />,
    },
    {
        path: "/PostAd",
        element: <PostAd />,
    },
    {
        path: "/detail/:adId",
        element: <Detail />,
    },
]);

function Router() {
    return <RouterProvider router={router} />
}

export default Router