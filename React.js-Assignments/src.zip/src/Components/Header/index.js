import './navbar.css';

function Header() {

  const gotoCart = () => {
    // Apne gotoCart function ka logic yahaan implement karen
  };

  const signout = () => {
    // Apne signout function ka logic yahaan implement karen
  };

  return (
    <div className="container-fluid mx-0" id='dashboard'>
      <div className="row pt-2" style={{ backgroundColor: "#f7f8f8" }}>
        <div className="col-3 col-md-2">
          <a href=""><img style={{ width: '50%' }} src="./Images/olx blue.png" className="img-fluid" alt="olx" /></a>
        </div>
        <div class="col-4 col-md-2">
        
<a href=""><img style={{width: '30%'}} src="./images/car.png" class="img-fluid" alt="Motors" /><small>Motors</small></a></div>
 
<div class="col-4 col-md-2">
<a href=""><img style={{width: '30%'}} src="./images/proparty.png" class="img-fluid" alt="Proparty" /><small>Proparty</small></a></div>

<div id="cart" class="col-2 col-md-2">
  <p id="email"></p>

  <img style={{ width: '40%' }} onClick={gotoCart} src="./images/pngwing.com.png"
          className="img-fluid"
          alt="Cart"/>
<p id="count"></p></div>
        {/* ... rest of your code ... */}
      </div>
      {/* ... rest of your code ... */}
      <div class="row" style={{backgroundColor: '#f7f8f8',
    alignItems: 'center'}}>
     
  <div class="col-12">
  <nav class="navbar navbar-expand-md">
                 
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon">
  </span></button>
  
<div class="collapse navbar-collapse" id="navbarSupportedContent">
  <ul class="navbar-nav mb-2 mt-2 col-12">

<li class="nav-item col-2 col-md-1 me-3"><a class="nav-link active" aria-current="page" href="#"><svg height="40" viewBox="0 0 36.289 20.768" alt="Olx logo"><path d="M18.9 20.77V0h4.93v20.77zM0 10.39a8.56 8.56 0 1 1 8.56 8.56A8.56 8.56 0 0 1 0 10.4zm5.97-.01a2.6 2.6 0 1 0 2.6-2.6 2.6 2.6 0 0 0-2.6 2.6zm27 5.2l-1.88-1.87-1.87 1.88H25.9V12.3l1.9-1.9-1.9-1.89V5.18h3.27l1.92 1.92 1.93-1.923h3.27v3.33l-1.9 1.9 1.9 1.9v3.27z"></path></svg></a></li>
  <li class="nav-item col-10 col-md-3 mt-1 me-3">
  <form action="">
  <select class="form-select form-select-lg">
  <option selected>Use current location</option>
  <option value="1"><a href="">Pakistan</a></option>
  <option value="2"><a href="">Canada</a></option>
  <option value="3"><a href="">Turky</a></option>
  <option value="4"><a href="">Amarica</a></option>
  <option value="5"><a href="">Saudi Arab</a></option>
  </select></form></li>
  
 <li class="nav-item col-10 col-md-4 mt-1">
  <form action="" class="d-flex">
  <div class="input-group">
         
  <input type="search" value="" className="form-control form-control-md" placeholder="Find Cars, Mobile Phones and more..." aria-label="Recipient's username" aria-describedby="button-addon"/>
    
  <button class="btn btn-outline-secondary" type="submit"> 
    <img width="33.9" height="33" src="./images/magnifying-glass.png" class="img-fluid" alt="" />
    </button>
  </div></form></li>
 <li id="naam" class="nav-item col-2 col-md-1 text-center mt-2 text-primary">
     <a class="nav-link" href='src/registration/login/login.html' id="lout" onclick={signout}>
  <u><b style={{fontSize: 'larger'}}>logout</b></u></a>
  </li>
  
  <li class="nav-item col-4 col-md-2 mt-2">
  <button onclick="location.href = './src/postAd/postAd.html'" id="btn" type="menu">+Sell</button>
    </li></ul></div></nav></div></div>
    </div>
  );
}

export default Header;


// import React from 'react';
// import './navbar.css';

// function Header() {

//   return (
//     <div className="container-fluid mx-0" id='dashboard'>
//       {/* ... (aapke code ka baki hissa) */}
//       <div id="cart" className="col-2 col-md-2">
//         <p id="email"></p>
        // <img
        //   style={{ width: '40%' }}
        //   onClick={gotoCart}
        //   src="./images/pngwing.com.png"
        //   className="img-fluid"
        //   alt="Cart"
        // />
//         <p id="count"></p>
//       </div>
//       {/* ... (aapke code ka baki hissa) */}
//       <li id="naam" className="nav-item col-2 col-md-1 text-center mt-2 text-primary">
//         <a className="nav-link" href='src/registration/login/login.html' id="lout" onClick={signout}>
//           <u><b style={{ fontSize: 'larger' }}>logout</b></u>
//         </a>
//       </li>
//       {/* ... (aapke code ka baki hissa) */}
//     </div>
//   );
// }

// export default Header;
