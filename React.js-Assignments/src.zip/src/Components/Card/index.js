import { useNavigate } from 'react-router-dom';

function Card(props) {
  const { title, amount, image, id } = props.item;
  const navigate = useNavigate();

  return (
    <div
      className='card'
      style={{ border: '1px solid black', width: 200, height: 300, margin: 20 }}
      onClick={() => navigate(`productScreen/${id}`)}
    >
      {/* Image div */}
      <div style={{ width: '100%', height: '70%', overflow: 'hidden' }}>
        <img
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          className='img-fluid'
          src={image}
          alt={title}
        />
      </div>

      {/* Title */}
      <h3>{title}</h3>

      {/* ID (Just for testing) and Amount */}
      <p>{id}</p>
      <h5>Rs. {amount}</h5>
    </div>
  );
}

export default Card;



// function renderAdItems(ads) {

  
  
//       if (i % 3 == 0) {
//        row = document.createElement('div')
//     row.className = 'row row-cols-1 row-cols-md-4 g-4 mt-1 mb-3';
//     row.style = "justify-content: space-evenly"
        
//      
//   }