import React, { useState } from 'react';
import './App.css'
import Card from "./Components";

const App = () => {
  const [input, setInput] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);


  const searchWeather = async () => {
    if (input) {
      try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${input}&appid=f794dfccd2b630217361984f2e8bd284`);
        const data = await response.json();
        setWeatherData(data);
        addToHistory(input);
      } catch (error) {
        console.error('Error fetching weather:', error);
      }
    }
  };

const addToHistory = (term) => {
  setSearchHistory(prevHistory => [...prevHistory, term]);
};

 return (
      <div>     
<div class="wrapper">
<label htmlFor="cityNameInput"> <center> Weather Application </center> </label>
<div class="input-box">
<input type="text" id="cityNameInput" placeholder="Enter Your City Name" maxLength={20} minLength={2} value={input} onChange={(e) => setInput(e.target.value)} required />
</div>
<button type="submit"  onClick={searchWeather} class="btn">Get Weather</button>
</div>
  
        <br />
  
        {weatherData ? ( <Card weatherData={weatherData} />) : (<div className="wrapper"> <center>Enter Your City Name First</center> </div>)}


  <div className="wrapper" style={{marginTop: '5%'}}>
  <p>Search History</p>
  <ul>
  {searchHistory.map((term, index) => (
  <li key={index}>{term}</li>
  ))}
 </ul>
</div>
      </div>
    );
};

export default App;


