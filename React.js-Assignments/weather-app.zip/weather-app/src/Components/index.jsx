import './Card.css'

const Card = ({weatherData})=> {
    return (
      <div class="card">
        <h2>{weatherData?.name}<>    </>
        {weatherData?.sys?.country}</h2>
        <h3>  Humidity : {weatherData?.main?.humidity}</h3>
        <h1>{weatherData?.main?.temp}°C</h1>

        <div class="sky">
            <div class="sun"></div>
            <div class="cloud">
                <div class="circle-small"></div>
                <div class="circle-tall"></div>
                <div class="circle-medium"></div>
            </div>
        </div>
        <h3><span>wind speed : { weatherData?.wind?.speed} <span class="dot">••</span> &nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;   weather: {weatherData?.weather[0]?.description}</span></h3>
      </div>
    );
};

export default Card;