import {createBrowserRouter,RouterProvider, } from "react-router-dom"
import Dashboard from "../Veiws/Dashboard";
import Detail from "../Veiws/Detail";
import Login from "../Veiws/Login";
import SignUp from "../Veiws/SignUp";
import PostAdd from "../Veiws/PostAdd";
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Dashboard />,
    },
    {
      path: "/detail/:id",
      element: <Detail />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/signup",
      element: <SignUp />,
    },
    {
      path: "/postAdd",
      element: <PostAdd />,
    },
  
  ]);
  function Router(){
    return  <RouterProvider router={router} />
  }
  export default Router;