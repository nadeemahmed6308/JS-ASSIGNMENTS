import { useEffect, useState } from "react";
import { getAllProducts } from "../../config/firebase"
import Footer from '../../components/Footer';
import Header from '../../components/Header';
import Card from '../../components/Card';


function Dashboard(){

    const[products,setproducts] = useState([]) 

    useEffect(() =>{
        getProducts()
    },[])

    async function getProducts(){
        // fetch('https://dummyjson.com/products')
        // .then((res) => res.json() )
        // .then(res => setproducts(res.products))
        const res = await getAllProducts()
        console.log('res', res)
        setproducts(res)
    }
    console.log(products)

    return <div>
 <Header />

 <div className="container-fluid mt-2 mb-4">
   <div className="row row-cols-1 row-cols-md-4 g-1 container-fluid">
{products.map(item => {
  return <Card  item={item}/>
})}
</div></div>
  
 <Footer />
     </div>
 }  
    
export default Dashboard;