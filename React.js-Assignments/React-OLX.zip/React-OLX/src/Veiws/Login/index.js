import {useNavigate } from "react-router-dom"
import './login.css'
import { login } from "../../config/firebase"


function Login(){
    const navigate = useNavigate()
   async function signin(){
      const allInputs = document.getElementsByClassName('input')
      const email = allInputs[0].value
      const password = allInputs[1].value
      try{
        if ( !email || !password ){
          alert('please  fill all the inputs!')
      return
      }
      await login({email,password})
      navigate('/')
      } catch(e){
        alert(e.message)
      }
    }
    return <div className='pic'>
        <div  class=" d-flex " style={{marginLeft: '38%'}}>
        <div id="signUpstyle">
         <div id="signup" class="card" style={{margin: 'auto'}}>
           <div class="row">
             <div class="col-lg-12">
             <div class="card-body">
                <h5 class="card-title">Email</h5>
                <input className="input" type="email" name="" id="lemail" placeholder="enter Email" />
    <p id="emailError" class="text-danger font-weight-bold"></p>
    <h5 class="card-title">Password</h5>
    <input className="input" type="password" name="" id="lpassword" placeholder="enter password" /><br /><br />
    <button onClick={signin}>login</button>
    <p>if you dont have account <a className="click" onClick={ () => navigate('/signup')}> click here </a></p>
                </div></div></div></div></div>
            </div>
    </div>
}
export default Login;

// //////

// import {useNavigate } from "react-router-dom"
// import './sign.css'
// import { Registered } from "../../config/firebase"


// function SignUp(){
//     const navigate = useNavigate()
//    async function signup() {
//         const allInputs = document.getElementsByClassName('input')
//         const name = allInputs[0].value
//         const email = allInputs[1].value
//         const password = allInputs[2].value
//         const number = allInputs[3].value
       
//        try {
//         if ( !name ||!email || !password|| !number ){
//             alert('please  fill all the inputs!')
//         return
//         }
//         await Registered({name,email,password,number})
        
//         navigate('/login')
//        } catch(e) {
//         alert(e.message)
//        }
//        for (var i=0; i< allInputs.length; i++){
//         allInputs[i].value = ''
//     }
       
//     }
//     return <div className="pic">
//         <h1>Login</h1>
//         <div  class=" d-flex " style={{marginLeft: '38%', marginTop: '10%'}}>
//         <div id="signUpstyle">
//          <div id="signup" class="card">
//            <div class="row">
//              <div class="col-lg-12">
//              <div class="card-body">
//              <h5 class="card-title">Full Name</h5>
//     <input className="input" type="name" name="name" id="name" placeholder="enter your Name" />
//     <p id="userNameError" class="text-danger font-weight-bold"></p>
//     <h5 class="card-title">Email</h5>
//     <input className="input" type="email" name="email" id="email" placeholder="enter Email" />
//     <p id="emailError" class="text-danger font-weight-bold"></p>
//         <h5 class="card-title">Password</h5>
//     <input className="input" type="password" name="password" id="password" placeholder="enter password" />
//     <h5 class="card-title">Number</h5>
 
//     <input className="input" type="text" name="number" id="number" placeholder="enter your phone number" /><br /><br />
//     <button onClick={signup}>signup</button>
//     <p>you have an account <a className="click"  onClick={() => navigate('/login')} >click here</a></p>
//                     </div></div></div>
//                     </div></div>
//                  </div>
//     </div>
// }
// export default SignUp