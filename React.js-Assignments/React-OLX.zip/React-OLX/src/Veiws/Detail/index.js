import { Container, Row, Col, Button } from 'react-bootstrap';
import { getSingleAd } from "../../config/firebase"
import './index.css'
import Card from 'react-bootstrap/Card';
import { Carousel } from 'react-bootstrap';
import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import Header from '../../components/Header'
import Footer from '../../components/Footer'


function Detail() {
  const { id } = useParams();

  console.log('nadeem', id)
  const [detailItem, setdetailItem] = useState([])
  const [like, setLike] = useState(false);


  useEffect(() => {
    getDetail()
  }, [])

  async function getDetail() {
    // fetch(`https://dummyjson.com/products/${id}`)
    //   .then((res) => res.json())
    //   .then(res => setdetailItem(res))

    const res = await getSingleAd(id)
    console.log('res', res)
    setdetailItem(res)
  }
  console.log(detailItem.image)
  const {title, description, image, amount } = detailItem

  return <div>
    <Header />


      {/* <Container> */}
      <div id="container" class="container-fluid">
        <Row>
          <Col sm={8}>
            <div className="container mt-5">
              <Carousel style={{ width: '90%'}}>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={image}
                    alt="First slide"
                  />
                  <Carousel.Caption>

                  </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={image}
                    alt="Second slide"
                  />
                  <Carousel.Caption>
                  </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={image}
                    alt="Third slide"
                  />
                  <Carousel.Caption>

                  </Carousel.Caption>
                </Carousel.Item>
              </Carousel>
            </div>
     {/* new code */}
     <div className='col mb-4 mt-3' style={{ width: '90%' }}>
      <div className="card h-100">
        <div className="card-body">

          <h5 className="card-title">{title}</h5>
          <p className="card-text">{description}</p>
        </div>
        <div style={{ paddingLeft: '5%', paddingBottom: '5%', display: 'flex', justifyContent: 'space-between' }}>
          <h5 className="card-text">Rs.{amount}</h5>
          <div className="float-right" style={{ paddingRight: '5%' }}>
        
          </div>

        </div>
      </div>
    </div>

    {/* new code  */}




            <Card className='mt-3' style={{ width: '90%' }}>
              <Card.Body>
                <Card.Title><h5>{title}</h5></Card.Title>
                <br />
                <Card.Text>
                <h1>Description</h1>
                  {description}
                </Card.Text>
                <Card.Text>
                 
                </Card.Text>
                <div className='emojies hide'>
        <img style={{ float: 'right', marginRight: '0px' }} width={'50px'} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAADlCAMAAAAP8WnWAAABKVBMVEX/AAD////9/Pz8+vr59fX7+Pj38vLy6ur17+/48/Pw5ubz6+vs4ODu4+Po2dnq3d3k09PfysrawsLPsLC8kZHZwcHCm5vVurrIpaXOr6/GoaGpcnK6jY22h4ejaGjTtrawfX2ygIChZWWQXFzuGRmSWFijZ2f8g4P9Z2f9X1/+QkL7np7+eHj7tLTh29vZzs795+fiW1v2Dw/EOjqmTEz4NDT7x8f8lpb8bm78e3v7jIz5trb3zs75qan9UVH12Nj0v7//IiL+0NDlxcXsmZn7Ly/isrLlnp7ojIzqf3//R0fcsrLyR0frdnbTmJjswMDrUlLThYXYdHTuNDTWWVnPYmK9dnbEZWXfPz+5amrqKirRQECuW1u3UVHYMzObVla6QEDQoKDlZWXmCv/mAAAPlElEQVR4nN2d+X/TRhPGZcnyfSfBcZzEOQkUSGiABkhTkra0pSW80NCW5gL6//8R7+7sqcvWsStZml8o/SSsvp6Z5xmtZMkoFTiMKD9s+oauQ0u+Wmg4xwqWZZmWRkLnYrBcnMVCwYllgMuybBTwH/jvqvnEJ+hdzYy02mw4+fODdWy7jIP8p00RFQGKT1GsJi9nyUlMDMczxv4t+DtZjwZZk/ElR4OPkZJIjWD7rJYIThzv4+9OjvYe3rt//97zFy8fHH/fwItVUNTrdM2k9SlhoH8M/SPN748fvHzxHNbcOzo5fWWzT1VaLDYc/eXa8d43hjd+2Dt+ZZcrNRSVOl8y1CcahGYBmYU+yuOXP/gs+c3eo7Zpl+sOvlhw5BcfHz3zWYXF4cPjBuBRwFBLBqEBmVmqHL84nLLks6NXVpksNnOtQDj4pUd+KXNn8KRda1abwFcPs2QwmlWqnPhlzM13UkMdIeFFhUO/YR/NXofE/eNatUr4Qn2i/mhm6bt7YVd8WS1DrVDRiQSHf/xB2IVwHB61qo0G5qvUZ3+iHjZ0iKXKg2nV6ImjSoWuFbyULxz62R8jrYTjRScGHkdr7kVd7/C0DJUyhc4PDv3gw6hL4XjYa7SBTyqYqXiUzI6BhuM5FjL+SYaDM0uPz+KshWKv2261G9XazIKR0mab9suYy529qjVF8sLAob6OuRaOn/dbFG9Wt5dI2qzSowTLndaqU+g8cGbpOMFiyGh/2u8ivCYtmMDk0bSVHv+eaLkTRIdW8qdzwyVlQ/Fmv9ttQetxYfFnw2kLbTdB8Qh7UACdCw7JZNLVkMn+tN/pitr0o2Npmzb+hIzTaiOIzp25x8lXM3DndVBt0uTZntKE/2HbibpNxKs2pbNmwcXVSVfcO+jR5NW9jUfNzYzlN944a7dF7oLhzNILNesZxutBTyTP2XgUramgJEk8b7QQHVrGXSHOzCloOB6/9CB5kq5wNuzbr1QuhT7FWs2bOidc5JlrWvyKSxPJpkM16ZBcOlW50tl+t42XcbedAy7SrDw7fjvo9zqYrgaiSc8VLCyTJ2pXegN0qO3MQDhb7YpoTaBrM1mxOJviT9Ew+h3Rdn5wZinW9Do1zjFdt81sFvauEFti5/bEw/1Oy1uYUubqypekuetKRmTpyBuKfo8UpiN1hkic+s8TxZu+oIO9x7LqfiNx3oPCrDtSJ2VOx5poWBn0+9wSUJiJZ1f/QNLsSZ2AUzMLeePd0gDXTIOcw1rfa1rmt16vy1LnhjNLyU49psQfS6g0wfCQaqqZXX3iGUodaIqUOp45basaZ8MhpUMneYpmV5/4o89S54bTJCck3lK6dqNyX98q531IXb0sJIXDvda3rHE+HA6waFY1foLG2QGkriKNKYb2qsTxbgJ0/9O6CKpLEEwhKQZNnBbz4XE4Ajqlc7kn3gzwECZLCoPT2Aw43iO6g9Cb5fHi9yUypoi6ZHB61zWMD6PJr7rXGOLUUUkRcEq2hWbE8kj7Eu+WqKSwuqRwOmZZZ3z7rfYlzocDKilOOM0tl068HS4569JIp+XSCTQs0LoUcKZml0stvqK67LabXC8JXJJLH3MUHyZEL8t0vjRS0pNU4nyC9BL5OGs6Aqdo7zfreL/gbDoDLhJrO5dLN56NJo6mI3BZH5WqGKG67IgJDOCUb1hmFSsL1OmIohgFcgI0gI2g6ciZAYXTP1mmFB9GDkUxlFwpnpf4kyqKDFcQmzOM/5axjVNFwXCm1s2hdOPbZaooRC4BTv0VkIzivYCzGNzzrA9KVbxdpnJZF3CaNzfSi7crDi8AuBA3cOYjLlaEFxQO7tnKMvcCAmcVZW42jNd3MFyHGR3AhbiTOR/B4JBcFhOOnRcUEW7BDVegnltxwJlFUsvLOyvy/AVwhdiSxXHhA1eYCeVi0QtXkM0vw/jkA1ecswIfuOKcz/nAFeZM/KMXTtcdS+nHXz5wBbkOYhj/eOEslfcbZxp/u+DQ+GU1sz4oVbG5uOKeLe3CXCtYXfQMzrbWe6NSjDME5z7lsYoyXF5gONfJqmUWZET5tOrZZjAtU++dX6nFRwInbxCh1BXE6P5BcO6tPcsuyAW6v1fvePYtLdvM+rDUxBqDI3epM7hC7KK8XluEHeeWfK3AtE1l35vLMj6tOacvCmcVQi4/ri26r8/huxlsXV9lSDX+XVt0X1nFLl4uZ31gKmJjTbI5S8AVQVFeb8pOwOBMq2zFfTzCHMUVh5PvQ0FeYJ9mfWjJ469NlxMQONMuF+B8dewWSw5nKfvWdlaxQ/TEdWMbKIqd+7OeT5urLrHkcOXTrA8uafzjEUsCh+SyXsv64JLGWNKTsnSPM37Mm5XzrYbLDVlPZDikKOWcj5cf6Xwi6Qn90gRqukrOT1jvbtDT8LbzSxN4d69cybcZ7GzQloP5xJbhEF29nOsLWVdSy/Hv5FI4065Xcn3F4F+p5ZzfwiJNV87x7Sg74w3scg4LF3Co6So5vgb5BLvcgqvlGBymq7WyPsT4cReq0ulyAg45Xa2cWx+/FFXp/UIuabpabi8f34y5EUgtJ8PVa5WsDzJujKWqrHvhsBnUajndbLhiVekwAhkO12U368OMF1vOqvQ8m4HWZS5vwr8IqEoBB3rZzOXm7PV4U1Sl/OwvCQ7VZbOWw1svL8fjNebgTf8n2ZC6bJ5mfajR4wbLyfLE/WAGBxzoZbOWuwFzZ8zlxKmVDjjw8epp1gcbNW6EnMBWs+9zv+CVALVq3lIHiZPkRKpKGQ7rZaWZt9Q9HdPTVPcDiFxwICnVaq4E83J9vOmSE98HCcJmQ63Z+CnrA44S1+sbzAfazod+ueFgBGtUc3SB/FZKXMP5uDYnHJOUdo4mzC1IHPMBp5y44EBSao3Gz1kfc9j4QhPHfGDKY1d56to5uUXxcHtq4lxwxA0a7dOsDztcPJU7zu0DXjh8MQulrpGLL8BcbBOPY4lz+oAbjqeu1cv6wMPE7joMJ1wq3YnzwNHUtXKgKUhN8FQZnDjPI/2pYLb2537E3NleH4OaBCbOC8e8bu7nlGtuA0IqZzzSX6TuTdZHPz2utsbEBga9oMT5wEHqmo3u/lybHS5Knjj8ZHGfxPm8AIVMmKgw9T5HNGFcb3E16bSrnqkyEM4iJwdzXZhXdKik/u168nYgHEldHaduf24vJDuK0vvM9GlwuOuwpnTmVjE/e9TEL3G+r4tiTt7d/y1rCv94soUt7s6I24DXv4PgmB1U2539udxyuKRFKdTExwaC4ZimdPpZg/jFLi/KaWoSACdpSmcOr0fegFLOVJNgOKIp1VZnf+42VG7lovR5d8YsODGnILo584OdbVdRBrMFvdBSKsw58wPmArOLcgocL8ye9idnR4kvW6GLctqrSEVh/pc1kYjb7btwwSpMUU5/iSwtzN7B3LQdb7jJYHZRToWjhdnu9AZZQ7H4LLlAx/f1V+HgyHcpSGHOS9vdOBoOitKewjYFTlbMg7k4+7kiDUdcYHZRzoBjhYnabg6GzEvacHw0mVGUs94njmfMChTmgb53zoSMQzJS0obDO8yBM2UYOFKYtO0mWcN95g036Pm+kC0ynIVfvA6FmbWoUDGBhuuxV+lNT9x0OGfbZSoqT7CYyGPXzIabCQeFyfzg4H12bFRMRMP5vL4yDhz4AaHLbFJBk8n6xuai5HB174tHI8PJhdnpLWUFx8REcrjZRTkbztF2vT+yYXvqFpMwDRcGztl2mUjmze66cO/QDRcWTrhdFpL5xCsmYRouFJxwuwZqu4PUT+5uGRuISbcRyuFCwznarn/wNl02ZAJCTKI0XEg4J10/1UtbO7sxxSQCnNR2/SW9r5FzxOFnxha54cLCQdsJuhQNAbPxqSsqW0g46gdYVDDdL2mxPd1ymkDV94XvSeGck0o/Jbu72b3LhZJMJhEaLgKcSzJTubb1RZhAdDGJCAeVyehSMHMwb6cJwM2iGuBkycR057rZsHlLBhdVTKLB8UmFSOaB5tcc3m57TCD0ZBIDjrYdp9N67nrpyxal4SLCCVEhdBoHMcomm0BEMYkMV5JEBdENtNEBmzA4JpRR+i0WnKDr95c03dq3I9hkg4skJtHhPHQXWth2CRsxuPhsUeG4IRC7Gyxp2DNysoHBgQlEbLgYcNIMrYnOw0YNLjpbdDjZEHTQudnimUBcOL10QWyR+y0mnMvMBypVxcUW07yTwHnolDmCYBspYIsLR0cVRqfIzZl3y2x0MEkPTrI7SqdkzvSyxTW4RHBa6G5Vs8WF89Il3qxVzxYbzkuX8Oz1ybZbJxOzxYfz0iXaV/migS0BHBnEZLoEe2I3cP7mwxbTBBLDUbq6oHsXl+3pLuyXONki7gYphvNW5nKsnfbDz5RtRWVNJoXz0A0XYgyaaCy5i/fwlLMlhPPSDSMbHrFushekli0pnIOuC3QRDe+KyCRn66pjSwwn6MgZUH9p+CEKG7cA2MOj5ziK2JLD+dB9Dc8GMknGEvVsCuAYXR12HvDFyeEopKzsfEZSQuxtRPfwxLlpcjYVcD50w1B77bdUSkAmNbApgZPo6G7tcBhiFvvCpYRaQLddVcqmBk7Q1Tjd1xl3nx5es3ZjFgB7eCrZFMExOtjPJIY3GU11vAvYUKDtRuyN7E8qZFMFx3YeuOH1lybDP2eVJEyTXCaxvSXYU/AJVXAuOpCVydeAW1awSop2AynRwaYODujwXnSFiSYuTd9xhQwlm452A3sj+8rK2BTC+Yjm0mTyzqMrh9fbd7GS0JLUIpM0VMI5RBPLCirNhZHL8j6tr7O0QUkyKdHAphaOiyZvPFSaC3Lydq7HKGssbaQkebupZlMMJ9GxxluaLIz43tHHjTHO2ipOGy9J0m4a2FTDEToiK1JprsCW9NuNtc3NNYyG0iZKkkiJBjblcEDHGk+U5ujD2dmHO4urq6uLGG15QSpJ3m6q2dTDETybNh6UJra8hdFo5Q7EyjLuNkgbKknSbrYONC1wXDRJaZLOA7xlFKMRyhrpNlKSOmSShg44Mq2w0sTJA7zhBGIIaDRt5AKVUueWQgscbzyimi3AQ3wQgz6gtRwqqYVNE5zsCTh5FI8ERUNp0+QAPHTBUU8gySN4iA9Hh6A1xZysi00fnFyaBK/VhWgRNN0liUMfnNAVitdotFGgPziaNiWhoRNOJA/j1ZrNKoomIsNo2tNW0gxHGw/w6pgPAjkbT5tWNs1wLHn46/TlermOAv2Bv7quP20l/XCEDtKHATEYS5p2Nv1wLHmYj4aZStpKqcCx7OG3spssaSmgpQRX4nwpkpXSg8ORKhiONOFSj0LD/R/wOOt4Ee2CcgAAAABJRU5ErkJggg==" alt="" />
     </div>
                <div  onClick={(e) => {like(e.target)}} style={{}}><img style={{ float: 'right', marginRight: '0px' }} width={50} src="https://static-00.iconduck.com/assets.00/heart-icon-512x461-rdoishra.png" alt="" /></div>
                <img style={{ float: 'right', marginRight: '20px' }} width={50} src="https://cdn-icons-png.flaticon.com/512/1358/1358023.png" alt="" />
              </Card.Body>
            </Card>
            <Card className='mt-3' style={{ width: '90%' }}>
              <Card.Body>
                <Card.Text>
                <h3>Rs, {amount}$</h3>
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          <Col sm={4}>
          <Card  className='mt-5' style={{ width: '100%',marginLeft:'-5%' }}>
      <Card.Body>
        <Card.Title><h4 className='details'><span><img width={'20%'} src="https://png.pngtree.com/png-clipart/20220213/original/pngtree-avatar-bussinesman-man-profile-icon-vector-illustration-png-image_7268049.png" alt="" /></span>Nadeem Ahmed</h4></Card.Title>
        <Card.Subtitle className="mb-2 text-muted">Member Since Dec 2020</Card.Subtitle>
        <br />
        <Card.Text>
        <div className="d-grid gap-2">
      <Button variant="primary" size="lg">
        Show Phone Number
      </Button>
      <Button variant="secondary" size="lg">
       Chat
      </Button>
    </div>.
        </Card.Text>
     
      </Card.Body>
    </Card>
    <Card className='mt-5' style={{ width: '100%',marginLeft:'-5%' }}>
      <Card.Body>
        <Card.Title><h1>Location</h1></Card.Title>
        <Card.Text>
          <img width={40} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBjwdZvFqJudRfAmH0P8oI0iQUm4Gf-6pDq2VUwEqBST8fRq9E_8xP69Vgcjou7wcSIRg&usqp=CAU" alt="" />
          G-8, Islamabad

        </Card.Text>
      </Card.Body>
    </Card>
          </Col>

        </Row>
        {/* </Container> */}
      </div>

<br /><br/>
<Footer />
  </div>
}
export default Detail;