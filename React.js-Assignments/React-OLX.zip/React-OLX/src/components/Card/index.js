import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import img from './img.png';
import img2 from './yellow.png';

function Card(props) {
  const { title, description, id, image, amount } = props.item;
  const navigate = useNavigate();

  const [like, setLike] = useState(false);

  const handleLikeClick = (e) => {
    e.stopPropagation(); // Event propagation ko rokne ke liye

    // Like toggle logic
    setLike(!like);
  };

  return (
    <div className="col mb-4">
      <div className="card h-100" onClick={() => navigate(`/detail/${id}`)}>
        <img style={{ height: '250px' }} src={image} className="card-img-top w-100" alt="" />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{description}</p>
        </div>
        <div style={{ paddingLeft: '5%', paddingBottom: '5%', display: 'flex', justifyContent: 'space-between' }}>
          <h5 className="card-text">Rs.{amount}</h5>
          <div className="float-right" style={{ paddingRight: '5%' }}>
            {like ? (
              <img width={20} onClick={handleLikeClick} src={img2} alt="Liked" />
            ) : (
              <img width={20} onClick={handleLikeClick} src={img} alt="Like" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Card;


