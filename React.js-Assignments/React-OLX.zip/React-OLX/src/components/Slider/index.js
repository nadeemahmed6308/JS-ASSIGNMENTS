// import Categories from '../Categories';

// function Slider() {
//   return (
//     <div className="container-fluid">
//       <div id="carouselExampleSlidesOnly" className="carousel slide" data-bs-ride="carousel" style={{width: '100%'}}>
//         <div className="carousel-inner">
//           <div className="carousel-item active" >
//             <img width={'100%'} src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
//           </div>
//           <div className="carousel-item">
//             <img width={'100%'} src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
//           </div>
//           <div className="carousel-item">
//             <img width={'100%'} src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
//           </div>
//         </div>
//       </div>

//       <Categories />
//     </div>
//   );
// }

// export default Slider;


import Categories from '../Categories';

function Slider() {
  return (
    <div className="container-fluid" style={{ width: '100%' }}>
      <div id="carouselExampleSlidesOnly" className="carousel slide" data-bs-ride="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
          </div>
          <div className="carousel-item">
            <img src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
          </div>
          <div className="carousel-item">
            <img src="https://images.olx.com.pk/thumbnails/295176473-800x600.webp" className="d-block w-100" alt="..." />
          </div>
        </div>
      </div>

      <Categories />
    </div>
  );
}

export default Slider;
