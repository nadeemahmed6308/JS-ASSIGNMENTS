function categories(){
    return(

        <>
        <p class="d-inline-flex gap-1">
 
 <p  data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
   <b>categories <img src="https://www.iconpacks.net/icons/2/free-arrow-down-icon-3101-thumb.png" width={'20px'} alt="" /></b>
   Mobile Phones {'\u00A0'}
    Car {'\u00A0'}
 Motorcycles {'\u00A0'}
 Houses {'\u00A0'}
 TV - Video - Audio {'\u00A0'}
 Tablets {'\u00A0'}
 Land & Plots {'\u00A0'}
 </p>
 </p>

 
<div class="collapse" id="collapseExample">
<div class="card card-body">
<div class="row">
<div class="col-lg-4">
<b>Mobiles</b><br />
          Mobile Phones<br />
          Accessories<br />
          Smart Watches<br />
          Tablets<br /><br />
          Cars<br />
          Cars Accessories<br />
          Spare Parts<br />
          Buses, Vans & Trucks<br />
          Rickshaw & Chingchi<br />
</div>
<div class="col-lg-4">
<b>Bikes</b><br />
      Motorcycles<br />
      Bicycles<br />
      Spare Parts<br />
      <b>Services</b><br />
      Travel & Visa<br />
      Domestic Help<br />
      Web Development<br />
      Car Services<br />
      Catering & Restaurant<br />
      Renting Services<br />
      Camera Installation<br />
      Tailor Services<br />
      Insurance Services<br />
</div>
<div class="col-lg-4">
<b>Jobs</b><br />
      Manufacturing<br />
      Real Estate<br />
      Human Resources<br />
      Security<br />
      Engineering<br />
      Advertising & PR<br />
      Internships<br />
      <b>Animals</b><br />
      Hens<br />
      Parrots<br />
      Cats<br />
      Ducks<br />
      Peacocks<br />
      Fertile Eggs<br />
      Horses<br />
</div>
</div>
</div>
</div>
        </>
    )
}

export default categories;