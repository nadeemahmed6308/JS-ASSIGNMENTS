import {createBrowserRouter,RouterProvider, } from "react-router-dom"
import Dashboard from "../Dashboard";
import Detail from "../Detail";
import Login from "../Login";
import SignUp from "../SignUp";
import Sell from "../Sell";
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Dashboard />,
    },
    {
      path: "/detail/:id",
      element: <Detail />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/signup",
      element: <SignUp />,
    },
    {
      path: "/sell",
      element: <Sell />,
    },
  
  ]);
  function Router(){
    return  <RouterProvider router={router} />
  }
  export default Router;