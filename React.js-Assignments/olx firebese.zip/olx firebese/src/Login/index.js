import {useNavigate } from "react-router-dom"
import './login.css'
import { login } from "../config/firebase"
function Login(){
    const navigate = useNavigate()
   async function signin(){
      const allInputs = document.getElementsByClassName('input')
      const email = allInputs[0].value
      const password = allInputs[1].value
      try{
        if ( !email || !password ){
          alert('please  fill all the inputs!')
      return
      }
      await login({email,password})
      navigate('/')
      } catch(e){
        alert(e.message)
      }
    }
    return <div className='pic'>
        <h1>Login</h1>
        <div  class=" d-flex " style={{marginLeft: '38%', marginTop: '10%'}}>
        <div id="signUpstyle">
         <div id="signup" class="card">
           <div class="row">
             <div class="col-lg-12">
             <div class="card-body">
                <h5 class="card-title">Email</h5>
                <input className="input" type="email" name="" id="lemail" placeholder="enter Email" />
    <p id="emailError" class="text-danger font-weight-bold"></p>
    <h5 class="card-title">Password</h5>
    <input className="input" type="password" name="" id="lpassword" placeholder="enter password" /><br /><br />
    <button onClick={signin}>login</button>
    <p>if you dont have account <a className="click" onClick={ () => navigate('/signup')}> click here </a></p>
                </div></div></div></div></div>
            </div>
    </div>
}
export default Login;