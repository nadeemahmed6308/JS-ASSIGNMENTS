import { postAdToDb } from "../config/firebase"
import React, { useState } from 'react';
import {useNavigate } from "react-router-dom"
function Sell(){
  const navigate = useNavigate()
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [brand, setBrand] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState(null);
  const handleImageChange = (e) => {
    setImage(e.target.files);
  };
   async function Post(){
     try {
            // Perform any additional validation if needed
      
            if (!title || !description || !brand || !price || !image) {
              alert('Please fill in all the inputs!');
              return;
            }
      
            const ad = {
              title,
              description,
              brand,
              price,
              image,
            };
      
            await postAdToDb(ad);
        navigate('/')
      }catch(e){
        alert(e.message)
      }
    }
    return <div>
<div id="container" class="container-fluid">
<div class="row" style={{backgroundColor:' #f7f8f8'}}>
<div class="col-3 col-md-2 "><img style={{width: '60px', marginTop: '5%'}} class="img-fluid" src="https://upload.wikimedia.org/wikipedia/commons/4/42/OLX_New_Logo.png" alt="icon" /></div>
</div>
</div>
<h1 style={{display: 'flex', justifyContent: 'center'}}>POST YOUR ADDS</h1>
<div style={{display: 'flex', justifyContent: 'center'}} > 
<div class="container">
<div  class="card" style={{width: '100%', marginTop: '5%'}}>
<div  class="card-body">
<h4 class="card-title">INCLUDE SOME DETAILS</h4>
<p>Add Title
          <input className="input" class="border border-success p-2 mb-2" style={{width: '100%'}} type="text" name="" id="title" onChange={(e) => setTitle(e.target.value)}  />
          Mention the key features of your item
        </p>
       <p>Add Description
            <input className="input" class="border border-success p-4 mb-2" style={{width: '100%', height:'150px'}}  type="text" name="" id="description" onChange={(e) => setDescription(e.target.value)} />
            Include condition, features and reason for selling
         </p>
         <p>Brand
            <input className="input" class="border border-success p-2 mb-2" style={{width: '100%'}} type="text" name="" id="brand" onChange={(e) => setBrand(e.target.value)} />
          </p>
          <hr class=" opacity-100" />
          <h4>SET A PRICE</h4>
          <p>Price
            <input className="input" class="border border-success p-2 mb-2" style={{width: '100%'}} type="text" name="" id="price" onChange={(e) => setPrice(e.target.value)} />
</p>
<p>picture
  <input className="input" onChange={handleImageChange} class="border border-success p-2 mb-2" style={{width: '100%'}} multiple type="file" />
  For the cover picture we recommend using the landscape mode.
</p>
<div class="d-grid gap-2 col-6 mx-auto">
  <button class="btn btn-primary" type="button" onClick={Post}>Post Now</button>

</div>
</div> 
</div>
</div>
</div>
    
    
    </div>
}
export default Sell;