import React, { useEffect, useState } from 'react';
import FbImageLibrary from 'react-fb-image-grid';
import Dashboard from './views/Dashboard';
import ContactUs from './views/ContactUs';
import AboutUs from './views/AboutUs';
import './App.css';

function App() {
  const [screen, setScreen] = useState('');
  const [products, setProducts] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  function getData() {
    fetch('https://dummyjson.com/products')
      .then((res) => res.json())
      .then((res) => {
        console.log(res.products);
        setProducts(res.products);
      });
  }

  if (!products?.length) {
    return <div>Loading...</div>;
  } 

  return (
    <div className="App">
      <header className="App-header">


      <div className='navbar'>
         <div>
            <button style={{width :"33%",height:"50%"}} key="dashboardBtn" onClick={() => setScreen('dashboard')}>Dashboard</button>
            <button style={{width :"33%",height:"50%"}} key="contactUsBtn" onClick={() => setScreen('contactUs')}>Contact Us</button>
            <button style={{width :"33%",height:"50%"}} key="aboutUsBtn" onClick={() => setScreen('aboutUs')}>About Us</button>
          </div>
<br/>
        <div style={{display: 'flex'}}>
          <h1 style={{color: 'blue'}}>Facebook</h1>
          <div style={{textAlign: 'right', width: '62vw'}}>
          <button key="plusBtn" style={{width :"15%",height:"100%"}}>
            <svg xmlns="http://www.w3.org/2000/svg" width="40%" height="95%" fill="currentColor" className="bi bi-plus" viewBox="0 0 16 16">
              <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
            </svg>
          </button>
          <button key="ProfileBtn" style={{width :"15%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg" width="40%" height="95%" fill="currentColor" className="bi bi-search" viewBox="0 0 16 16">
      <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
    </svg></button>
          <button key="MMSBtn" style={{width :"15%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg" width="40%" height="95%" fill="currentColor" className="bi bi-messenger" viewBox="0 0 16 16">
      <path d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.639.639 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.639.639 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76m5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z"/>
    </svg></button></div>
        
          {/* Add similar changes for other buttons */}
        </div></div><br/>

 <div className='icons'>
    {/* ... (other icons) */}
    <button style={{width :"17%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg" width="60%" height="95%" fill="currentColor" className="bi bi-house-door" viewBox="0 0 16 16">
      <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4z"/>
    </svg></button> 
    <button style={{width :"17%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg" width="60%" height="95%" fill="currentColor" className="bi bi-play-btn" viewBox="0 0 16 16">
      <path d="M6.79 5.093A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"/>
      <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm15 0a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1z"/>
    </svg></button> 
    <button style={{width :"17%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg"  width="60%" height="95%" fill="currentColor" className="bi bi-people" viewBox="0 0 16 16">
      <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0M6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816M4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0m3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4"/>
    </svg></button>
    <button style={{width :"17%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg"  width="60%" height="95%" fill="currentColor" className="bi bi-gift" viewBox="0 0 16 16">
      <path d="M3 2.5a2.5 2.5 0 0 1 5 0 2.5 2.5 0 0 1 5 0v.006c0 .07 0 .27-.038.494H15a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 14.5V7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h2.038A2.968 2.968 0 0 1 3 2.506zm1.068.5H7v-.5a1.5 1.5 0 1 0-3 0c0 .085.002.274.045.43a.522.522 0 0 0 .023.07M9 3h2.932a.56.56 0 0 0 .023-.07c.043-.156.045-.345.045-.43a1.5 1.5 0 0 0-3 0zM1 4v2h6V4zm8 0v2h6V4zm5 3H9v8h4.5a.5.5 0 0 0 .5-.5zm-7 8V7H2v7.5a.5.5 0 0 0 .5.5z"/>
    </svg></button>
    <button style={{width :"17%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg"  width="60%" height="95%" fill="currentColor" className="bi bi-bell" viewBox="0 0 16 16">
      <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2M8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6"/>
    </svg></button>
    <button style={{width :"15%",height:"100%"}}><svg xmlns="http://www.w3.org/2000/svg"  width="60%" height="95%" fill="currentColor" className="bi bi-list" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"/>
    </svg></button>
          {/* ... (other buttons) */}
        </div>

        {screen ? <div>
        {screen === 'dashboard' && <Dashboard />}
      {screen === 'contactUs' && <ContactUs />}
      {screen === 'aboutUs' && <AboutUs />}
</div>: 
       <div>
        {/* <h1 style={{ textAlign: 'center' }}>Post</h1> */}
        {products.map(function (item, index) {
          return (
            <div key={index} className="post-container">
              <h1>{item.title}</h1>
              <h3>{item.brand}</h3>
              <p>{item.description}</p>
              <div className='images-container'>
                {item.images && <FbImageLibrary images={item.images} className='images' />}
              </div>
              <div className='button-container'>
                <button className='d-1' style={{width :"45%",height:"100%"}}>Like</button>
                <button className='d-2' style={{width :"45%",height:"100%"}}>Share</button>
                <button style={{width :"45%",height:"100%"}}>Comments</button>
              </div>
            </div>
          );
        })} </div>}
      </header>
    </div>
  );
}

export default App;
