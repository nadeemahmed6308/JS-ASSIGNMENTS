import CustomBtn from '../../components/CustomBtn'

function ContactUs() {
    return <div style={{ width: '100vw', height: '100vw', background: 'blue' , textAlign:'center'}}>
        <h1>Contact Us</h1>

        <CustomBtn text='Contact Us' bgColor='green' />
    </div>
}

export default ContactUs