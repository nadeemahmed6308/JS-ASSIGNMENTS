import CustomBtn from '../../components/CustomBtn'

function AboutUs() {
    return <div style={{ width: '100vw', height: '100vw', background: 'green', textAlign:'center' }}>
        <h1>About Us</h1>

        <CustomBtn text='Click Here' bgColor='purple' />
    </div>
}

export default AboutUs