import CustomBtn from '../../components/CustomBtn'
//import FbPost from '../../components/FbPost'
import './index.css';

function Dashboard() {
    return <div className='container'>

        <h1>Dashboard</h1>

        <p>kjdklasjfdslaknfjkalndflkas</p>

        {/* <FbPost /> */}

        <CustomBtn text='Submit' bgColor='red' />
    </div>
}

export default Dashboard
